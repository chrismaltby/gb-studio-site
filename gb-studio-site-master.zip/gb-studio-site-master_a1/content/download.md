---
title: "Downloads"
date: 2018-04-29T14:14:44Z
draft: false
---

## Windows
* **Squirrel Installer**    
  [GB Studio-win32-x64-squirrel-1.0.0.zip](https://github.com/chrismaltby/gb-studio/releases/download/v1.0.0/GB.Studio-win32-x64-squirrel-1.0.0.zip)  
  *Installs to C:\\ automatically*

* **Manual Install Zip**  
  [GB Studio-win32-x64-1.0.0.zip](https://github.com/chrismaltby/gb-studio/releases/download/v1.0.0/GB.Studio-win32-x64-1.0.0.zip)  

## MacOS

* **Application Package**  
  [GB Studio-darwin-x64-1.0.0.zip](https://github.com/chrismaltby/gb-studio/releases/download/v1.0.0/GB.Studio-darwin-x64-1.0.0.zip)  

## Linux

* **Ubuntu / Debian-based**  
  [gb-studio_1.0.0_amd64.deb](https://github.com/chrismaltby/gb-studio/releases/download/v1.0.0/gb-studio_1.0.0_amd64.deb)

* **Fedora / RPM-based**  
  [gb-studio-1.0.0.x86_64.rpm](https://github.com/chrismaltby/gb-studio/releases/download/v1.0.0/gb-studio-1.0.0.x86_64.rpm)

## Next: [Installation](/docs/installation)
