Printable version (using theme for content)
