---
title: "About GB Studio"
date: 2018-01-28T14:14:44Z
draft: false
---

Hi, my name is [Chris Maltby](https://www.chrismaltby.com).

GB Studio began as number of disconnected scripts and tools which were eventually
used to create [Untitled GB Game](https://chrismaltby.itch.io/untitled-gb-game), a
game built in one week for Bored Pixels 3, a pixel art game jam where the theme was "Game Boy".

After completing the jam I realised that with a bit of work I could get the tools into a state where they could usable by other people, maybe even by people who had never made a
game before. This application is the result of that effort, hopefully you find
it intuitive and fun to use.

I can't wait to see what you make!
