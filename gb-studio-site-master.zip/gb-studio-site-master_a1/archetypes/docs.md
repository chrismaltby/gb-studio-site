---
title: "{{ replace .TranslationBaseName "-" " " | title }}"
date: {{ .Date }}
draft: true
tags: ["A","Bcd"]
hello: "AAGoodbye"
---
